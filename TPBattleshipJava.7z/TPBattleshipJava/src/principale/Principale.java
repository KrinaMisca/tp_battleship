package principale;
import vue.InterfaceGraphique;


		
	

		public class Principale {
			public static void main(String[] args) {
				InterfaceGraphique ig = new InterfaceGraphique("Battleship");
				
			}
		

	

}
